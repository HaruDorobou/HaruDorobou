import socket
import threading

import time

from Cryptodome.Random import get_random_bytes
from Cryptodome.Cipher import AES
from Cryptodome.Util.Padding import pad, unpad

import base64
import pyDH



# AES 암호화 복호화 함수 정의
def encryption(raw, key, iv):
    aes_obj = AES.new(key, AES.MODE_CBC,iv)
    raw = aes_obj.encrypt(pad(raw, 16))
    encrypted_msg = base64.b64encode(raw).decode('utf-8')
    return encrypted_msg

def decryption(enc, key, iv):
    aes_obj = AES.new(key, AES.MODE_CBC, iv)
    enc = enc.encode('utf-8')
    enc = base64.b64decode(enc)
    enc = unpad(aes_obj.decrypt(enc), 16)
    enc = enc.decode('utf-8')
    return enc

# 서버 연결정보; 자체 서버 실행시 변경 가능
SERVER_HOST = "homework.islab.work"
SERVER_PORT = 8080

connectSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
connectSocket.connect((SERVER_HOST, SERVER_PORT))

METHOD = ['CONNECT', 'DISCONNECT', 'KEYXCHG', 'KEYXCHGRST', 'MSGSEND']
HEADERS = ['Algo:', 'Credential:', 'Timestamp:', 'Nonce:', 'From:', 'To:']
Block_Size = 16

# 전역변수 정의
global key_request_flag # 키 교환 진행시 사용하는 분기 Flag
key_request_flag = 0

global user_info # 메세지에 담을 프로그램 실행 주체의 유저 이름 정보
user_info = ''

global my_dh # 프로그램 실행 주체의 디피-헬만 전역 객체

global shared_key_list # 다중 사용자들의 key룰 저장할 딕셔너리 전역 객체
shared_key_list = {}

global iv_list # 다중 사용들의 IV를 저장할 딕셔너리 전역 객체
iv_list = {}


def socket_read():
    while True:
        readbuff = connectSocket.recv(2048)

        if len(readbuff) == 0:
            continue

        recv_payload = readbuff.decode('utf-8')
        parse_payload(recv_payload)


def socket_send():
    global user_info
    global key_request_flag
    global my_dh
    global shared_key_list
    global iv_list

    while True:
        time.sleep(0.5) # 서버 부담 최소화
        
        # Main 콘솔 텍스트 UI 정의
        print('\n====== Initiating ======')
        print("Type Method You Want ")
        print("'CONNECT', 'DISCONNECT', 'KEYXCHG', 'KEYXCHGRST', 'MSGSEND'")
        s = input()
        if s not in METHOD:
            while s not in METHOD:
                print("Wrong METHOD")
                print("Type Method You Want ")
                s = input()

        # 서버에 연결 및 해제를 같은 구간에서 처리
        if s in ['CONNECT', 'DISCONNECT']:
            print("====== Server Con/Disconn Message Send =======")
            print("Input User Name")
            user_info = input()
            msg = """3EPROTO {0}
Credential: {1}""".format(s, user_info)
            print(msg)
            send_bytes = msg.encode('utf-8')
            connectSocket.sendall(send_bytes)
            print("====== Message Send End ======")
        
        # 키 교환 및 재교환을 같은 구간에서 처리
        if s in ['KEYXCHG', 'KEYXCHGRST']:
            print("====== Key Exchange Request Start ======")
            # 키 교한을 직접 수행하므로 IV를 직접 생성함
            iv = get_random_bytes(16)
            iv_b64_enc = base64.b64encode(iv).decode('utf-8')

            # 키 교환을 직접 수행하는 입장에서 공유할 디피-헬만 키 생성
            my_dh = pyDH.DiffieHellman()
            my_dh_pubkey = my_dh.gen_public_key()

            # 메시지 작성 .format 형식을 이용하여 줄넘김 처리한 msg 생성
            print("Input Target User")
            input_to = input()
            msg = """3EPROTO {0}
Algo: AES-256-CBC, Diffie-Hellman
From: {1}
To: {2}
       
{3}     
{4}
""".format(s, user_info, input_to, str(my_dh_pubkey), str(iv_b64_enc))

            key_request_flag = 1 # Flag Setting

            send_bytes = msg.encode('utf-8')
            connectSocket.sendall(send_bytes)
            print("====== Key Exchange Request End ======")

        # 메세지 전송
        if s in ['MSGSEND']:
            print("====== Message Send Start ======")

            # 메시지 전송은 키 교환을 마치고 진행함
            # 에러 처리 및 기본 정보 입력 CUI
            print("Input Target User\n")
            input_to = input()
            if input_to not in shared_key_list:
                while input_to not in shared_key_list:
                    print('This User Not In The List : Retype')
                    input_to = input()

            print("Input Message To Send\n")
            shared_key = shared_key_list[input_to]
            iv = iv_list[input_to]

            target_msg = input('MSG: ')
            target_msg = target_msg.encode('utf-8')
            
            # 작성항 메시지를 암호화 모듈을 통해 암호화
            target_msg = encryption(target_msg, shared_key, iv)

            msg = """3EPROTO MSGSEND
From: {0}
To: {1}
Nonce: A/Xqf            
            
{2}            
""".format(user_info, input_to, target_msg)
            print(msg)
            
            # 작성한 메시지를 암호화하고 그 결과룰 메시지에 담아서 전송
            send_bytes = msg.encode('utf-8')
            connectSocket.sendall(send_bytes)
            print('====== Message Send End ======\n')

def parse_payload(payload):
    global user_info
    global key_request_flag
    global my_dh
    global shared_key_list
    global iv_list

    # 수신된 페이로드를 여기서 처리; 필요할 경우 추가 함수 정의 가능
    print('\n======= Payload Detected =======')
    print(payload)
    payload = payload.split('\n')

    # 키 교환을 요청 받았을 경우 분기 시작
    if payload[0].split(' ', 2)[1] in ['KEYXCHG', 'KEYXCHGRST']:
        # 해당 분기는 '키 교환을 요청한 적 없고 기다리고 있었을 때'를 의미함
        if key_request_flag == 0:
            if payload[0].split(' ', 2)[1] == 'KEYXCHG' and \
                    payload[2].split(':', 2)[1] in shared_key_list:
                print("====== Key Exchange Message Send ======\n")
                msg = """3EPROTO KEYXCHGFAIL
Algo: AES-256-CBC, Diffie-Hellman
From: {0}
To: {1}
""".format(user_info, payload[2].split(':', 2)[1])

                print(msg)
                print('====== Message Send End ======\n')
                send_bytes = msg.encode('utf-8')
                # 메시지 확인용 출력부
                connectSocket.sendall(send_bytes)

            else:
                dh_ano = pyDH.DiffieHellman()
                ano_pubkey = dh_ano.gen_public_key()

                shared_key = dh_ano.gen_shared_key(int(payload[6]))
                shared_key = shared_key[:32].encode('utf-8')
                shared_key_list[payload[2].split(':', 2)[1]] = shared_key
                # print('shared_key: ')
                # print(shared_key)
                iv = base64.b64decode(payload[7].encode('utf-8'))
                iv_list[payload[2].split(':', 2)[1]] = iv

                # print('shared_key_list :', shared_key_list)
                # print('iv_list :', iv_list)
                msg = """3EPROTO KEYXCHG
Algo: AES-256-CBC, Diffie-Hellman
From: {0}
To: {1}

{2}
{3}""".format(user_info, payload[2].split(':', 2)[1], str(ano_pubkey), payload[7])

                print(msg)
                print('====== Message Send End ======\n')
                send_bytes = msg.encode('utf-8')
                # 메시지 학인용 출력부
                connectSocket.sendall(send_bytes)

        if key_request_flag == 1:
            # 해당 분기는 먼저 키 교환 절차를 수행했을 때를 의미함
            # 먼저 보냈으므로 상대가 디피-헬만 키를 생성하여(공유키) 전송한 상태
            shared_key = my_dh.gen_shared_key(int(payload[6]))
            shared_key = shared_key[:32].encode('utf-8')
            # print('shared_key: ')
            # print(shared_key)
            shared_key_list[payload[2].split(':', 2)[1]] = shared_key

            iv = payload[7].encode('utf-8')
            iv = base64.b64decode(iv)
            iv_list[payload[2].split(':', 2)[1]] = iv

            # print('shared_key_list :', shared_key_list)
            # print('iv_list :', iv_list)
            key_request_flag = 0
            # 서로 송수신한 공유키를 이용하여 AES에 사용핧 AES Key를 만든다

    # 메세지 수신 상황
    if payload[0].split(' ', 2)[1] in ['MSGRECV']:

        shared_key = shared_key_list[payload[2].split(':', 2)[1]]
        iv = iv_list[payload[2].split(':', 2)[1]]
        
        # 도착한 메시지를 복호화 한다
        dec_msg = decryption(payload[5], shared_key, iv)
        print('\n====== Decrypted Payload Message ======')
        
        # 페이로드 메시지를 재조립
        dec_payload = """{0}
{1}
{2}
{3}
{4}
{5}""".format(payload[0], payload[1]. payload[2], payload[3], payload[4], dec_msg)
        print(dec_payload)
        print('====== Sequence End ======\n')

    # 연결 종료 (DISCONNECT)
    if payload[0].split(' ', 2)[1] in ['BYE']:
        user_info = ''
        shared_key_list = {}
        iv_list = {}
        # 연결 종료시 리스트를 초기화

    print("\nType Method You Want ")
    print("'CONNECT', 'DISCONNECT', 'KEYXCHG', 'KEYXCHGRST', 'MSGSEND'")
    pass


reading_thread = threading.Thread(target=socket_read)
sending_thread = threading.Thread(target=socket_send)

reading_thread.start()
sending_thread.start()

reading_thread.join()
sending_thread.join()
